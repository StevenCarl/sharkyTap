package com.example.cjignacio.tapsharky;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Point;
import android.media.MediaPlayer;
import android.os.Handler;
import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.os.Handler;

import org.w3c.dom.Text;

import java.util.Timer;
import java.util.TimerTask;

public class main extends AppCompatActivity {



    private TextView scoreLabel;
    private TextView startLabel;
    private ImageView shark;
    private ImageView fishy1;
    private ImageView fishy2;
    private ImageView poison;

    // Size
    private int frameHeight;
    private int sharkSize;
    private int screenWidth;
    private int screenHeight;

    // Positioning

    private int sharkY;
    private int fishy1X;
    private int fishy1Y;
    private int fishy2X;
    private int fishy2Y;
    private int poisonX;
    private int poisonY;

    //Speed
    private int sharkSpeed;
    private int fishy1Speed;
    private int fishy2Speed;
    private int poisonSpeed;


    // Score
    private int score = 0;

    // Initialize Class
    private Handler handler = new Handler();
    private Timer timer = new Timer();
    private SoundPlayer sound;

    // Status Check
    private boolean action_flg=false;
    private boolean start_flg=false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        sound = new SoundPlayer(this);

        scoreLabel = (TextView) findViewById(R.id.scoreLabel);
        startLabel = (TextView) findViewById(R.id.startLabel);
        shark  = (ImageView) findViewById(R.id.shark);
        fishy1 = (ImageView) findViewById(R.id.fishy1);
        fishy2 = (ImageView) findViewById(R.id.fishy2);
        poison = (ImageView) findViewById(R.id.poison);

        // Get Screen Size
        WindowManager wm = getWindowManager();
        Display disp = wm.getDefaultDisplay();
        Point size = new Point();
        disp.getSize(size);

        screenWidth= size.x;
        screenHeight=size.y;

        // Move to out of screen
        fishy1.setX(-80);
        fishy1.setY(-80);
        fishy2.setX(-80);
        fishy2.setY(-80);
        poison.setX(-80);
        poison.setY(-80);

        //Now for Nexus4 Screenwidth: 768 and height:1184
        // speed Shark:20,fishy1:12,fishy2:20,poison:16

        sharkSpeed = Math.round(screenHeight / 60F);    // 1184/60 19.7333.... =>20
        fishy1Speed = Math.round(screenWidth/60F);      // 768/60= 12.8 => 13
        fishy2Speed = Math.round(screenWidth/36F);      // 768/36= 21.333 =>21
        poisonSpeed = Math.round(screenWidth/45F);      // 768/45 = 17.06...=>17

//        Log.v("SPEED_SHARK",sharkSpeed+"");
//        Log.v("SPEED_FISHY1",fishy1Speed+"");
//        Log.v("SPEED_FISHY2",fishy2Speed+"");
//        Log.v("SPEED_POISON",poisonSpeed+"");



        scoreLabel.setText("Score: 0" );

    }

    //     Where the dialog box is created
//    @Override
//    public void onBackPressed() {
//        onPause();
//        AlertDialog alertDialog = new AlertDialog.Builder(this)
//                .setTitle("Stop Playing?")
//                .setMessage("Are you sure you want to exit?")
//
//                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
//                    @Override
//                    public void onClick(DialogInterface dialog, int which) {
//                        finish();
//                    }
//                })
//                .setNegativeButton("No", new DialogInterface.OnClickListener() {
//                    @Override
//                    public void onClick(DialogInterface dialog, int which) {
//                        dialog.cancel();
//                    }
//                })
//                .show();
//    }

    public void changePos(){

        hitCheck();

        // Fishy1
        fishy1X -= fishy1Speed;
        if (fishy1X < 0){
            fishy1X = screenWidth + 20;
            fishy1Y = (int) Math.floor(Math.random()* (frameHeight-fishy1.getHeight()));
        }
        fishy1.setX(fishy1X);
        fishy1.setY(fishy1Y);

        // Poison
        poisonX -= poisonSpeed;
        if (poisonX < 0){
            poisonX = screenWidth + 10;
            poisonY = (int) Math.floor(Math.random()* (frameHeight-poison.getHeight()));
        }
        poison.setX(poisonX);
        poison.setY(poisonY);

        //Fishy2
        fishy2X -= fishy2Speed;
        if (fishy2X < 0){
            fishy2X = screenWidth + 5000;
            fishy2Y = (int) Math.floor(Math.random()* (frameHeight-fishy2.getHeight()));
        }
        fishy2.setX(fishy2X);
        fishy2.setY(fishy2Y);

        // Move Sharky

        if (action_flg == true){
            // Touching
            sharkY -=sharkSpeed;
        }
        else {
            // Releasing
            sharkY +=20;
        }

        // Checkbox position
        if (sharkY < 0) sharkY = 0;

        if (sharkY > frameHeight - sharkSize) sharkY = frameHeight - sharkSize;

        shark.setY(sharkY);

        scoreLabel.setText("Score:" +score);

    }

    public void hitCheck(){
        // If the center of the fishy is at the box it counts as a hit...

        //Fishy1

        int fishy1CenterX = fishy1X + fishy1.getWidth()/2;
        int fishy1CenterY = fishy1Y + fishy1.getHeight()/2;

        // 0 <= fishyCenterX <= sharkWidth
        // sharkY <= fishyCenterX <= sharkY + sharkHeight

        if (0 <= fishy1CenterX && fishy1CenterX <= sharkSize &&
                sharkY <= fishy1CenterY && fishy1CenterY <= sharkY + sharkSize){
            score +=1;
            fishy1X = -10;
            sound.playeatSound();
        }

        // Fishy2
        int fishy2CenterX = fishy2X + fishy2.getWidth()/2;
        int fishy2CenterY = fishy2Y + fishy2.getHeight()/2;

        if (0 <= fishy2CenterX && fishy2CenterX <= sharkSize &&
                sharkY <= fishy2CenterY && fishy2CenterY <= sharkY + sharkSize){
            score +=20;
            fishy2X = -10;
            sound.playeatSound();
        }

        //Poison
        int poisonCenterX = poisonX + poison.getWidth()/2;
        int poisonCenterY = poisonY + poison.getHeight()/2;

        if (0 <= poisonCenterX && poisonCenterX <= sharkSize &&
                sharkY <= poisonCenterY && poisonCenterY <= sharkY + sharkSize){

            //Temporary!
            //            score +=10;
            //            poisonX = -10;
            timer.cancel();
            timer = null;

            sound.playhitSound();

            // Show result
            Intent intent = new Intent(getApplicationContext(),result.class);
            intent.putExtra("SCORE",score);
            startActivity(intent);

        }


    }


    public boolean onTouchEvent(MotionEvent me){



            if (start_flg == false){

                start_flg = true;

//                Set Background Music
//                MediaPlayer player = MediaPlayer.create(this, Settings.System.DEFAULT_RINGTONE_URI);
//                player.setLooping(true);
//                player.start();

                 /* Why get frame height and box height here?
                    Because the screen size is not set in onCreate()*/
                FrameLayout frame = (FrameLayout) findViewById(R.id.frame);
                frameHeight = frame.getHeight();

                sharkY = (int)shark.getY();

                // The box is a square (height and width) are same...
                sharkSize = shark.getHeight();


                startLabel.setVisibility(View.GONE);

                timer.schedule(new TimerTask() {
                    @Override
                    public void run() {
                        handler.post(new Runnable() {
                            @Override
                            public void run() {
                                changePos();
                            }
                        });
                    }
                }, 0,20);
            }
            else {
                if (me.getAction()== MotionEvent.ACTION_DOWN){
                    action_flg=true;
                }
                else if (me.getAction()== MotionEvent.ACTION_UP){
                    action_flg=false;
                }
            }



            return true;
    }
}
