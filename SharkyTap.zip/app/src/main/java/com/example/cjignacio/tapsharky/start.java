package com.example.cjignacio.tapsharky;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import android.os.Handler;

import java.security.Key;

public class start extends AppCompatActivity {

    Button play;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);

        // For Background Music
        play = (Button)findViewById(R.id.button_play);
        final MediaPlayer mp = MediaPlayer.create(start.this,R.raw.babyshark);
        mp.start();
        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mp.isPlaying()){
                    mp.pause();
                    play.setBackgroundResource(R.drawable.mute);
                }
                else {;
                    mp.start();
                    play.setBackgroundResource(R.drawable.music);
                }
            }
        });
    }

    boolean twice;
    @Override
    public void onBackPressed() {
//        super.onBackPressed();
        if (twice == true){
            Intent intent = new Intent(Intent.ACTION_MAIN);
            intent.addCategory(Intent.CATEGORY_HOME);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
            finish();
            System.exit(0);
        }
        Toast.makeText(start.this,"Please press BACK again to exit", Toast.LENGTH_SHORT).show();
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                twice = false;
            }
        }, 2000);
        twice = true;
    }

    public void startGame(View view) {
        startActivity(new Intent(getApplicationContext(), main.class));
    }
}


